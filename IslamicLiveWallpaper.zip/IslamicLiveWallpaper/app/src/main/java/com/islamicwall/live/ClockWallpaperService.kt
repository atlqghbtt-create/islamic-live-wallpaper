package com.islamicwall.live

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Canvas
import android.os.Build
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

class ClockWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = ClockEngine()

    inner class ClockEngine : Engine() {
        private val r = Renderer(this@ClockWallpaperService)
        private val prefs = getSharedPreferences("w", MODE_PRIVATE)
        private var receiving = false
        private val rx = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { draw() }
        }
        private val pl = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> draw() }

        override fun onCreate(h: SurfaceHolder) { super.onCreate(h); prefs.registerOnSharedPreferenceChangeListener(pl) }
        override fun onDestroy() { prefs.unregisterOnSharedPreferenceChangeListener(pl); stop(); super.onDestroy() }
        override fun onVisibilityChanged(v: Boolean) { if (v) { start(); draw() } else stop() }
        override fun onSurfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) { super.onSurfaceChanged(h, f, w, hh); draw() }
        override fun onSurfaceRedrawNeeded(h: SurfaceHolder) { draw() }

        private fun start() {
            if (receiving) return
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_TIME_TICK); addAction(Intent.ACTION_TIME_CHANGED)
                addAction(Intent.ACTION_TIMEZONE_CHANGED); addAction(Intent.ACTION_DATE_CHANGED)
            }
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(rx, f)
            receiving = true
        }
        private fun stop() { if (receiving) { try { unregisterReceiver(rx) } catch (e: Exception) {}; receiving = false } }

        private fun draw() {
            var c: Canvas? = null
            try {
                c = surfaceHolder.lockCanvas() ?: return
                r.draw(c, c.width, c.height)
            } catch (e: Exception) {
            } finally {
                if (c != null) try { surfaceHolder.unlockCanvasAndPost(c) } catch (e: Exception) {}
            }
        }
    }
}
