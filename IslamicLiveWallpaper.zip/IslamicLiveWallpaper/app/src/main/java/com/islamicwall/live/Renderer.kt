package com.islamicwall.live

import android.content.Context
import android.graphics.*
import android.icu.text.SimpleDateFormat
import android.icu.util.ULocale
import android.media.ExifInterface
import java.io.File
import java.util.Date
import java.util.Locale
import java.util.Random

/** يرسم الخلفية + الساعة + التاريخ. يُستخدم في المعاينة وفي الخلفية الحية. */
class Renderer(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("w", Context.MODE_PRIVATE)
    private val file = File(ctx.filesDir, "bg.jpg")
    private var bg: Bitmap? = null
    private var key = ""
    private val bp = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val fHij = SimpleDateFormat("d MMMM y 'هـ'", ULocale("ar_SA@calendar=islamic-umalqura;numbers=latn"))
    private val fDay = SimpleDateFormat("EEEE", ULocale("ar_DZ@numbers=latn"))
    private val fGre = SimpleDateFormat("d MMMM y 'م'", ULocale("ar_DZ@numbers=latn"))
    private val fClk = java.text.SimpleDateFormat("HH:mm", Locale.ENGLISH)

    private fun ensure(w: Int, h: Int) {
        val k = "${prefs.getLong("bgv", 0)}:$w:$h"
        if (bg != null && k == key) return
        key = k
        bg = (if (file.exists()) load(w, h) else null) ?: procedural(w, h)
    }

    private fun load(w: Int, h: Int): Bitmap? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.path, o)
            var s = 1
            while (o.outWidth / (s * 2) >= w && o.outHeight / (s * 2) >= h) s *= 2
            val b = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = s })
                ?: return null
            val deg = when (ExifInterface(file.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
            }
            if (deg == 0f) b else Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg) }, true)
        } catch (e: Exception) { null }
    }

    private fun procedural(w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), 0xFF04120F.toInt(), 0xFF0B3D33.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = w * .004f; p.color = 0x66D9B45A
        val r = Random(7)
        repeat(40) {
            val x = r.nextFloat() * w; val y = r.nextFloat() * h; val rad = w * (.015f + r.nextFloat() * .035f)
            val path = Path()
            for (i in 0 until 16) {
                val q = if (i % 2 == 0) rad else rad * .55f
                val a = i * Math.PI / 8
                val px = x + q * Math.cos(a).toFloat(); val py = y + q * Math.sin(a).toFloat()
                if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close(); c.drawPath(path, p)
        }
        return b
    }

    fun draw(c: Canvas, w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        ensure(w, h)
        val b = bg!!
        val k = maxOf(w / b.width.toFloat(), h / b.height.toFloat())
        c.drawBitmap(b, Matrix().apply { setScale(k, k); postTranslate((w - b.width * k) / 2, (h - b.height * k) / 2) }, bp)

        val now = System.currentTimeMillis()
        val clk = fClk.format(Date(now))
        val t = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            textAlign = Paint.Align.CENTER; textSize = 100f
        }
        t.textSize = 100f * w * .8f / t.measureText(clk)
        val fm = t.fontMetrics
        val sy = 1.45f
        val top = h * prefs.getInt("y", 30) / 100f
        val base = top / sy - fm.ascent
        t.shader = LinearGradient(0f, base + fm.ascent, 0f, base + fm.descent, 0xCCFFFFFF.toInt(), 0x44FFFFFF, Shader.TileMode.CLAMP)
        c.save(); c.scale(1f, sy); c.drawText(clk, w / 2f, base, t); c.restore()

        val ds = w * .052f
        val dp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = ds
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setShadowLayer(ds * .3f, 0f, ds * .08f, 0xAA000000.toInt())
        }
        var y = top + (fm.descent - fm.ascent) * sy + ds * 1.2f
        c.drawText(fDay.format(Date(now)), w / 2f, y, dp)
        dp.textSize = ds * .85f
        y += ds * 1.5f
        c.drawText(fHij.format(Date(now + prefs.getInt("off", 0) * 86400000L)), w / 2f, y, dp)
        y += ds * 1.35f
        c.drawText(fGre.format(Date(now)), w / 2f, y, dp)
    }
}
