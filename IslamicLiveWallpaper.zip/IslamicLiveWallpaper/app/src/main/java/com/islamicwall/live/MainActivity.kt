package com.islamicwall.live

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("w", MODE_PRIVATE) }
    private fun bump() = prefs.edit().putLong("bgv", System.currentTimeMillis()).apply()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dp = resources.displayMetrics.density
        val r = Renderer(this)
        val pv = object : View(this) { override fun onDraw(c: Canvas) { r.draw(c, width, height) } }
        pv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, 28 * dp) }
        }
        pv.clipToOutline = true
        val tick = object : Runnable { override fun run() { pv.invalidate(); pv.postDelayed(this, 1000) } }
        pv.post(tick)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding((20 * dp).toInt(), (28 * dp).toInt(), (20 * dp).toInt(), (24 * dp).toInt())
        }
        fun tv(t: String, sz: Float, col: Int) = TextView(this).apply { text = t; textSize = sz; setTextColor(col); gravity = Gravity.CENTER }
        fun add(v: View) = root.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = (10 * dp).toInt() })
        fun btn(t: String, pri: Boolean, f: (Button) -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; textSize = 15f
            setTextColor(if (pri) 0xFF1C1606.toInt() else 0xFFF3EFE4.toInt())
            background = GradientDrawable().apply { cornerRadius = 16 * dp; setColor(if (pri) 0xFFE2BD62.toInt() else 0xFF1A2326.toInt()) }
            setOnClickListener { f(this) }
        }

        add(tv("خلفيات إسلامية حية", 20f, 0xFFE2BD62.toInt()))
        val pw = (resources.displayMetrics.widthPixels * .5f).toInt()
        root.addView(pv, LinearLayout.LayoutParams(pw, (pw * 19.5f / 9f).toInt()).apply { topMargin = (14 * dp).toInt() })

        add(tv("موضع الساعة", 14f, 0xFFA3AEAB.toInt()))
        add(SeekBar(this).apply {
            max = 60; progress = prefs.getInt("y", 30) - 10
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { prefs.edit().putInt("y", p + 10).apply() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        add(btn("تعيين كخلفية حية", true) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(this, ClockWallpaperService::class.java)))
            } catch (e: Exception) { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) }
        })
        add(btn("اختيار صورة الخلفية من المعرض", false) {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 1)
        })
        fun offLabel() = "تعديل التاريخ الهجري: ${prefs.getInt("off", 0)} يوم"
        add(btn(offLabel(), false) { bt ->
            prefs.edit().putInt("off", (prefs.getInt("off", 0) + 3) % 5 - 2).apply(); bt.text = offLabel()
        })
        add(btn("استعادة الخلفية الافتراضية", false) { File(filesDir, "bg.jpg").delete(); bump() })
        add(tv("الساعة والتاريخ يتحدثان تلقائياً كل دقيقة.", 12f, 0xFFA3AEAB.toInt()))

        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF090E10.toInt()); addView(root) })
    }

    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        super.onActivityResult(req, res, d)
        if (req != 1 || res != RESULT_OK) return
        val u = d?.data ?: return
        Thread {
            try {
                contentResolver.openInputStream(u)?.use { i -> File(filesDir, "bg.jpg").outputStream().use { o -> i.copyTo(o) } }
                bump()
            } catch (e: Exception) {}
        }.start()
    }
}
